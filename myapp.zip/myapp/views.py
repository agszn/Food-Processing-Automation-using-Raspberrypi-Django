from django.shortcuts import render, redirect,  get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .forms import *
from .models import *
from django.db.models import Q

from django.http import JsonResponse
from django.conf import settings
import os

import joblib
import numpy as np

def base(request):
    return render(request, 'base.html')

def about(request):
    return render(request, 'about/about.html')

def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            #create a new registration object and avoid saving it yet
            new_user = user_form.save(commit=False)
            #reset the choosen password
            new_user.set_password(user_form.cleaned_data['password'])
            #save the new registration
            new_user.save()
            return render(request, 'registration/register_done.html',{'new_user':new_user})
    else:
        user_form = UserRegistrationForm()
    return render(request, 'registration/register.html',{'user_form':user_form})

def profile(request):
    return render(request, 'profile/profile.html')



@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = EditProfileForm(request.POST, instance=request.user)
        if user_form.is_valid():
            user_form.save()
            messages.success(request, 'Your profile was successfully updated!')
            return redirect('profile')
    else:
        user_form = EditProfileForm(instance=request.user)
    
    return render(request, 'profile/edit_profile.html', {'user_form': user_form})

@login_required
def delete_account(request):
    if request.method == 'POST':
        request.user.delete()
        messages.success(request, 'Your account was successfully deleted.')
        return redirect('base')  # Redirect to the homepage or another page after deletion

    return render(request, 'registration/delete_account.html')
# das
@login_required
def dashboard(request):
    users_count = User.objects.all().count()
    consumers = Consumer.objects.all().count
    notify_users = Notification.objects.all().count()
    review_count = Review.objects.all().count()

    context = {
        'users_count':users_count,
        'consumers':consumers,
        'notify_users':notify_users,
        'review_count':review_count,
        'barData': [10, 20, 30],
        'lineData': [30, 25, 35],
        'pieData': [10, 40, 50],
        'scatterData': [{'x': 10, 'y': 20}, {'x': 15, 'y': 10}, {'x': 20, 'y': 30}],
        
    }
    return render(request, "dashboard/dashboard_crop.html", context=context)
#CRUD operations start here
@login_required
def dashvalues(request):
    consumers = Consumer.objects.all()
    search_query = ""
    
    if request.method == "POST": 
        if "create" in request.POST:
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            Consumer.objects.create(
                name=name,
                email=email,
                image=image,
                content=content
            )
            messages.success(request, "Consumer added successfully")
    
        elif "update" in request.POST:
            id = request.POST.get("id")
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            consumer = get_object_or_404(Consumer, id=id)
            consumer.name = name
            consumer.email = email
            consumer.image = image
            consumer.content = content
            consumer.save()
            messages.success(request, "Consumer updated successfully")
    
        elif "delete" in request.POST:
            id = request.POST.get("id")
            Consumer.objects.get(id=id).delete()
            messages.success(request, "Consumer deleted successfully")
        
        elif "search" in request.POST:
            search_query = request.POST.get("query")
            consumers = Consumer.objects.filter(Q(name__icontains=search_query) | Q(email__icontains=search_query))

    context = {
        "consumers": consumers, 
        "search_query": search_query
    }
    return render(request, "crud/dashvalue.html", context=context)
# CRUD operations end here

# Contact start
@login_required
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thank you for contacting us!")
            return redirect('dashboard')  # Redirect to the same page to show the modal
    else:
        form = ContactForm()

    return render(request, 'contact/contact_form.html', {'form': form})

# contact end

# review start
def add_review(request, consumer_id):
    consumer = get_object_or_404(Consumer, id=consumer_id)
    consumer_name = consumer.name

    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            # Assuming you have a Review model with fields 'comment' and 'rating'
            review = form.save(commit=False)
            review.consumer = consumer
            review.save()
            # You may want to add a success message here
            return redirect('dashboard')  # Redirect to the dashboard or any other page
    else:
        form = ReviewForm()

    return render(request, 'review/review.html', {'consumer_id': consumer_id, 'consumer_name': consumer_name, 'form': form})
# review end

# views.py


def view_reviews(request, consumer_id):
    consumer = get_object_or_404(Consumer, id=consumer_id)
    reviews = Review.objects.filter(consumer=consumer)

    return render(request, 'review/view_reviews.html', {'consumer': consumer, 'reviews': reviews})

#notification

@login_required
def user_notifications(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'notification/user_notifications.html', {'notifications': notifications})


import smtplib
from email.message import EmailMessage
from django.core.mail import EmailMessage
from django.shortcuts import render, redirect

from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib import messages

@login_required
def send_email(request):
    if request.method == 'POST':
        receiver = request.POST.get('receiver')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        email = EmailMessage(
            subject=subject,
            body=message,
            from_email=settings.EMAIL_HOST_USER,
            to=[receiver],
        )
        try:
            email.send()
            messages.success(request, 'Email sent successfully!')
        except:
            messages.error(request, 'Failed to send email.')

        return redirect('send_email')

    return render(request, 'email/sendemail.html')


@login_required
def chat(request):
    return render(request, 'chat/chat.html')

from django.shortcuts import render
import serial
import time
from django.http import HttpResponse

def sensor_data(request):
    # Replace 'COM6' with your Arduino's serial port
    serial_port = 'COM3'
    baud_rate = 9600

    try:
        # Establish serial connection
        ser = serial.Serial(serial_port, baud_rate)

        # Read data from Arduino
        data = ser.readline().decode('latin-1').strip()

        # Close serial connection
        ser.close()

        # Pass the data to the template
        return render(request, 'sensor_val.html', {'data': data})
    except serial.SerialException:
        # Handle serial port error
        return HttpResponse("Error: Serial port not available or accessible.")



from django.http import HttpResponse
import serial
import time

def send_signal_to_arduino(request):
    # Define the serial port and baud rate
    serial_port = 'COM5'  # Change 'COMX' to your Arduino's serial port
    baud_rate = 9600

    try:
        # Initialize the serial connection
        ser = serial.Serial(serial_port, baud_rate)
        print("Serial connection established")

        # Send a signal to start Arduino
        ser.write(b'Rice')
        print("Signal sent to Arduino")

        # Close the serial connection
        ser.close()

        return HttpResponse("Signal sent to Arduino successfully.")
    except Exception as e:
        return HttpResponse(f"An error occurred: {str(e)}")


# ----------------------------------------------------------------
# rice
import serial
import time

# communicate.py

def communicate_with_serial_rice_w(serial_port, baud_rate):
    received_data = []

    # Initialize serial communication
    ser = serial.Serial(serial_port, baud_rate)

    def send_message(message):
        # Encode the message as bytes and send it over serial
        ser.write(message.encode('utf-8'))

    try:
        # Example: sending a message to adjust temperature thresholds to 'w'
        send_message("w")

    except KeyboardInterrupt:
        print("Keyboard Interrupt")

    try:
        while True:
            # Read serial data line by line
            line = ser.readline().decode('utf-8').strip()
            
            # Add the received data to the list
            received_data.append(line)
            print(line)

            # Add your logic here to process the received data

    except KeyboardInterrupt:
        print("Keyboard Interrupt")
    
    # Close serial connection
    ser.close()

    # Return the received data
    return received_data

# views.py
from django.shortcuts import render
from .models import ReceivedData

from django.shortcuts import render
from .models import ReceivedData

from django.http import JsonResponse
from .models import ReceivedData

from django.http import JsonResponse

def serial_data_view(request):
    try:
        # Call the function to communicate with serial and get the received data
        received_data = communicate_with_serial_rice_w('COM4', 9600)
        
        # Process the received data if needed
        
        # Return a JSON response with the processed data
        return JsonResponse({'received_data': received_data})
    
    except Exception as e:
        # Print any exceptions for debugging
        print("Error occurred:", str(e))
        return JsonResponse({'error': str(e)})  # Return error response



# =================================================================
# wheat 
# communicate.py

import serial

def communicate_with_serial_rice_q(serial_port, baud_rate):
    received_data = []

    # Initialize serial communication
    ser = serial.Serial(serial_port, baud_rate)

    def send_message(message):
        # Encode the message as bytes and send it over serial
        ser.write(message.encode('utf-8'))

    try:
        # Example: sending a message to adjust temperature thresholds to 'w'
        send_message("q")

    except KeyboardInterrupt:
        print("Keyboard Interrupt")

    try:
        while True:
            # Read serial data line by line
            line = ser.readline().decode('utf-8').strip()
            
            # Add the received data to the list
            received_data.append(line)
            print(line)
            # Add your logic here to process the received data

    except KeyboardInterrupt:
        print("Keyboard Interrupt")
    
    # Close serial connection
    ser.close()

    # Return the received data
    return received_data

# views.py

from django.shortcuts import render

def serial_data_view_q(request):
    try:
        # Call the function to communicate with serial and get the received data
        received_data = communicate_with_serial_rice_q('COM4', 9600)
        return JsonResponse({'received_data': received_data})
        
        
    except Exception as e:
        # Print any exceptions for debugging
        print("Error occurred :", str(e))
        return JsonResponse({'error': str(e)})  # Return error response
    
    # Return the received data in the HTTP response

